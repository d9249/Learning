# ResNet

### 스터디 진행일
2020.4.30

## 참고 논문
* Kaiming He et al., [Deep Residual Learning for Image Recognition](https://arxiv.org/pdf/1512.03385.pdf)

## 목차
1. Paper Review
2. Discussion

## 1. Paper Review
2014 ILSVRC([Large Scale Visual Recognition Challenge](http://image-net.org/challenges/LSVRC/2014/)) 대회에 등장한 GoogleNet과 VGGNet 모델은 신경망 층수를 대폭 늘리는 Deep Neural Network를 이용하여 image classification의 학습 오차를 획기적으로 줄일 수 있다는 사실을 보여주었습니다. 2013년까지 대회에서 등장했던 고성능의 신경망들은 많아야 8개 층에 불과했으나, 2014년도에 20여개 층으로, 이번에 살펴볼 논문 속 모델인 ResNet에서는 152개 층으로 전년도에 비해 7배가 넘게 깊어졌습니다.

<p align="center">
  <img src="./img/1.png">
</p>

참고: [Armando Vieira, "The Revolution of Depth"](https://medium.com/@Lidinwise/the-revolution-of-depth-facf174924f5)


그렇다면 신경망을 깊게 만드는 것만으로 더 좋은 신경망을 만들 수 있을까요? ResNet 논문의 저자들은 기존의 깊은 신경망 방식(VGGNet)을 이용한 ConvNet모델 2개(20-layer, 56-layer)를 만든 후 training error와 test error를 측정했습니다. 실험 결과, 20-layer 신경망에 비해 오히려 56-layer 신경망이 더 높은 error를 보였습니다. 즉, 기존의 방식으로는 단순히 신경망의 층수를 증가시키는 것으로는 모델의 정확도를 높일 수 없습니다.

임의의 얕은 신경망 하나와 깊은 신경망 하나를 생각해봅시다. 우선, 얕은 신경망보다 training error가 높지 않은 깊은 신경망은 간단히 생각해낼 수 있습니다. 만약 깊은 신경망의 층 일부가 얕은 신경망의 모든 층과 동일하고, 나머지 층은 모두 identity mapping(input을 그대로 출력)이라면, 학습을 진행할 때 깊은 신경망의 training error가 얕은 신경망보다 높을 수 없을 것입니다. 하지만, 저자들은 기존의 방법으로는 이 깊은 신경망보다 더 좋은 신경망을 만드는 것이 어렵다고 설명합니다.

그래서 논문에서는 이 문제를 해결하기 위해 새로운 학습 방법을 제시합니다.

### Residual Learning
기존 신경망이 input X에 대해 최적의 함수 H(X)를 찾아가는 과정이라면, Residual Learning은 F(X)=H(X)-X를 residual로 정의하고 이 F(X)를 H(X)에 근사시킵니다. 앞에서 설명했듯이 어떠한 신경망 모델에 추가된 층들이 모두 identity mapping인 경우, 층이 깊어졌음에도 training error는 높아지지 않을 것이라는 발상에서 착안된 것입니다.

<p align="center">
  <img src="./img/2.png">
</p>

Residual F(X)를 계산할 때 사용되는 X는 "shortcut connection"을 통해 가져옵니다. 그림에서 둥근 화살표가 이에 해당됩니다. 이 "shortcut connection"은 신경망의 여러 층을 뛰어넘어(skip) X의 정보를 그대로 전달합니다. 저자들은 이러한 "shortcut connection"들이 추가되어도 네트워크 성능이 나빠지지 않는다고 설명합니다. extra parameter가 추가되지 않고, 단순 합 연산이기 때문에 추가적인 computational complexity도 필요하지 않기 때문입니다. 실제로 Residual Learning을 사용하지 않은 VGG와 FLOPs를 비교했을 때, 오히려 ResNet이 더 낮은 연산 복잡도를 보였습니다. 아래 그림에서 VGG-19(왼쪽 모델, 19-layer)의 FLOPs는 19.6 billion인 반면, ResNet(오른쪽 모델)은 34-layer임에도 FLOPs가 6분의 1 수준인 3.6 billion에 그쳤습니다.

### Network Architecture
<p align="center">
  <img src="./img/3.png">
</p>

논문에서는 실험을 위해 plain network와 residual network를 준비했습니다. 그림(예시: 34-layer) 가운데의 plain network와 오른쪽 residual network은 공통적으로 동일한 convolution layer와 하나의 1000 fully-connected layer로 구성되어 있습니다. convolution layer 대부분은 3x3 filter로 이루어져 있으며, 어느 layer에서 feature map size가 절반이 될 때마다 연산량 유지를 위해 filter의 수를 2배로 늘려줍니다.

두 모델의 유일한 차이점은 shortcut connection의 유무입니다. Residual network는 plain network에서 identity shortcut connection(둥근 화살표)들이 추가된 모델입니다. Identity shortcut들은 입출력값의 차원이 같다면 그대로 사용 가능합니다(실선 화살표). 문제는 점선 화살표로 표시된 shortcut들인데, 이는 map size 변화로 입력값보다 출력값의 차원이 커져 identity shortcut을 그대로 사용할 수 없습니다. 저자들은 이를 해결하기 위한 방법 두 가지로 zero-padding과 projection을 제시하였고, (A) identity와 zero-padding 사용, (B) identity와 projection 사용, (C) 모든 shortcut에 projection 사용이라는 3가지 방안을 두고 실험을 진행하였습니다. 우선, zero-padding에서 0이 추가된 차원들은 residual learning의 효과를 볼 수 없기 때문에 B가 A보다 효과적입니다. C가 B보다 정확도 면에서는 우월하지만, C를 사용할 경우 memory/time complexity가 급격히 증가하기 때문에, 효율성을 위해 B를 선택했다고 설명합니다.

### Deeper Bottleneck Architectures
더 깊은 모델(50/101/152-layer)을 만들기 위해서, 2-layer에서 이루어졌던 residual learning을 3-layer로 늘려줍니다.

<p align="center">
  <img src="./img/4.png">
</p>


그림에서 1x1 layer들은 차원을 감소하고 증가(복원)시키는 역할을 수행합니다. 이때, time complexity와 model size 유지를 위해 위에서 설명한 option B를 사용합니다.

### Evaluation
<p align="center">
  <img src="./img/5.png">
</p>

위 그래프에 따르면 기존의 방법을 이용한 plain model은 층이 깊어졌을 때 training error가 증가하였으나, residual Learning을 이용한 ResNet은 층이 깊어질수록 error 또한 감소하는 모습을 보였습니다. 또한 2015년 당시 다른 모델들과도 비교했을 때 training error와 test error 모두에서 압도적인 정확도를 보여 2015 ILSVRC classification 부문에서 우승을 차지했습니다. ImageNet뿐만 아니라 다른 dataset(CIFAR-10)에서도 높은 정확도를 보였으며, image classification 이외에도 object detection, localization 등 다른 CV 분야에도 적용이 가능했습니다.

#### Other recognition tasks
* Object Detection: Faster R-CNN 기반으로 앞에서 사용했던 classification 모델 중 ResNet-50과 ResNet-101을 사용하여 PASCAL VOC와 MS COCO dataset을 학습해본 결과, 그 당시 최고의 성능을 가진 모델들을 능가하는 정확도를 보였습니다.
* Localization: Object localization은 image의 분류에서 그치지 않고, 해당 object의 위치를 나타내는 bounding box를 출력해야 합니다. 논문에서는 RPN 알고리즘을 일부 수정 후 ResNet 모델을 적용시켰는데, VGGNet이 33.1%의 center-crop error를 보인 반면, RPN 알고리즘을 사용한 ResNet-101 모델은 이를 13.3%까지 줄였습니다.

### Exploring over 1000 layers

논문에서는 극단적으로 깊은 신경망에 대해서도 실험을 진행했습니다. 무려 1202층의 신경망을 구성하여 학습을 진행했으나, 오히려 100여개 층을 가진 신경망에 비해 높은 error를 보였습니다. 저자들은 해당 모델이 dataset에 비해 불필요하게 많은 layer와 parameter를 가진 것 같으며, overfitting을 방지하기 위한 maxout/dropout도 적용하지 않았기 때문에 개선의 여지가 있다고 설명합니다.

## 2. Discussion

스터디 중 제기된 논의점과 의견을 정리합니다.

* ResNet이 더 많은 layer를 갖고 있음에도 VGGNet에 비해 연산량(FLOPs)이 작은 이유?
  - fully-connected layer가 3개인 VGGNet에 비해 하나뿐인 점도 이유가 될 수 있을 것 같다.
* Residual Learning이 얼마나 효과적인가?
  - 기존의 방식에 batch normalization과 dropout을 사용하는 것보다 ResNet의 성능이 더 좋을 것인가?
* ResNet의 모든 shortcut들을 projection shortcut으로 사용하면 더 나은 성능을 낼 것으로 기대하는데, 왜 dimension 증가가 일어나는 부분에서만 projection shortcut을 사용하고 나머지는 identity shortcut을 사용했는가?
  - memory/time complexity를 줄이기 위해서이다.
  - ResNet은 정확도뿐만 아니라 성능(연산 복잡도)에도 큰 신경을 쓰고 있다.
