#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv) {
	printf("Hello World!\n");
	printf("%s\n", argv[1]);
	int num = atoi(argv[1]);
	char text;
	for (int i=0; i <= num; i++) {
		scanf("%s\n", &text);
		printf("%s\n", &text);
	}
}


/* how are you? and good bye. input 2 text
output how are you? and good bye. 
scanf("%s %s %s", &text1, &text2, &text3);
		scanf("%s %s", &text4, &text5);
		printf("%s %s %s\n", &text1, &text2, &text3);
		printf("%s %s\n", &text4, &text5);
*/
