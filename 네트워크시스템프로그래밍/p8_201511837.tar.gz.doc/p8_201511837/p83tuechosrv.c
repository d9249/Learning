#include <sys/time.h> 
#include <sys/socket.h> 
#include <sys/types.h> 
#include <sys/stat.h> 
#include <unistd.h> 
#include <stdlib.h> 
#include <stdio.h> 
#include <string.h> 
#include <netinet/in.h> 
#include <arpa/inet.h> 

int main(int argc, char **argv)
{
    int server_sockfd, client_sockfd, sockfd;
    int fd_num;    
    int state, client_len;
    int i, maxi, maxfd;
    char buf[255];
    char line[255];
    FILE *fp;
    int client[FD_SETSIZE];
    struct sockaddr_in clientaddr, serveraddr;
    fd_set readfds, allfds;
    if (argc != 2)
    {
        printf("Usage : ./zipcode [port]\n");
        printf("예    : ./zipcode 4444\n");
        exit(0);
    }
    if ((fp = fopen("zipcode.txt", "r")) == NULL)
    {
        perror("file open error : ");
        exit(0);
    }
    fd_num = 0;
    if ((fp = fopen("zipcode.txt", "r")) == NULL)
    {
        perror("file open error : ");
        exit(0);
    }
    if ((server_sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        perror("socket error : ");
        exit(0);
    }
    bzero(&serveraddr, sizeof(serveraddr));
    serveraddr.sin_family = AF_INET;
    serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);
    serveraddr.sin_port = htons(atoi(argv[1]));

    state = bind (server_sockfd, (struct sockaddr *)&serveraddr, 
                  sizeof(serveraddr));            
    if (state == -1)
    {
        perror("bind error : ");
        exit(0);
    }    
    state = listen(server_sockfd, 5);
    if (state == -1)
    {
        perror("listen error : ");                
        exit(0);
    }
    client_sockfd = server_sockfd;
    maxi = -1;
    maxfd = server_sockfd;
    for (i = 0; i < FD_SETSIZE; i++)
    {
        client[i] = -1;
    }
    FD_ZERO(&readfds);
    FD_SET(server_sockfd, &readfds);
    memset(line, 0x00, 255);
    while(1) {
        allfds = readfds;
        fd_num = select(maxfd + 1 , &allfds, (fd_set *)0, 
                      (fd_set *)0, NULL);
        if (FD_ISSET(server_sockfd, &allfds)) {
            client_len = sizeof(clientaddr);
            client_sockfd = accept(server_sockfd, 
                    (struct sockaddr *)&clientaddr, &client_len);
            for (i = 0; i < FD_SETSIZE; i++)
            {
                if (client[i] < 0)
                {
                    client[i] = client_sockfd;
                    printf("%d : %d\n", i, client_sockfd);
                    break;
                }
            }
            if (i == FD_SETSIZE)
            {
                close(sockfd);
                client[i] = -1;
            }
            FD_SET(client_sockfd,&readfds);
            if (client_sockfd > maxfd)
                maxfd = client_sockfd;
            if (i > maxi)
                maxi = i;
            if (--fd_num <= 0)
                continue;
        }
        for (i = 0; i <= maxi; i++)
        {
            if ((sockfd = client[i]) < 0)
            {
                continue;    
            }

            printf("maxi %d\n", maxi);
            if (FD_ISSET(sockfd, &allfds))
            {
                rewind(fp);
                memset(buf, 0x00, 255);
                if (read(sockfd, buf, 255) <= 0)
                {
                    close(sockfd);
                    FD_CLR(sockfd, &readfds);    
                    client[i] = -1;
                }
                else
                {
                    if (strncmp(buf, "quit", 4) ==0)            
                    {
                        write(sockfd, "bye bye\n", 8);
                        close(sockfd);
                        FD_CLR(sockfd, &readfds);    
                        client[i] = -1;
                        break;
                    }
                    while(fgets(line, 255, fp) != NULL)
                    {
                        if (strstr(line, buf) != NULL)
                            write(sockfd, line, 255);
                        memset(line, 0x00, 255);
                    }
                    write(sockfd, "end", 255);
                }
                if (--fd_num <= 0)
                    break;
            }
        }
    }
}
