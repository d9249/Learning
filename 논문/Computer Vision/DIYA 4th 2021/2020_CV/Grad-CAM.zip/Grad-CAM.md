# Grad-CAM

### 참고 논문

[Grad-CAM: Visual Explanations from Deep Networks via Gradient-based Localization]: https://arxiv.org/pdf/1610.02391.pdf

by Ramprasaath et al.



## Introduction

### CNN의 한계

* CNN은 CV 분야에서 엄청난 성능을 보여주지만, 모델을 직관적으로 해석하기 어려움
* accuracy와 simplicity (interpretability) 사이의 trade-off



### Transparent model의 필요성

* 모델이 transparent하다: 설명이 가능하다, 왜 그러한 결과를 output하는지 설명할 수 있다
* Transparent model이 제시하는 근거를 다양하게 활용할 수 있음
* AI의 성능이 인간의 능력에 비해 떨어지는 경우: failure cases 분석을 통해 모델 개선에 활용
* AI의 성능이 인간의 능력과 동등한 경우: 인간의 분석과 의사결정에 적절한 confidence 제공
* AI의 성능이 인간의 능력보다 뛰어난 경우 (AlphaGo): machine teaching에 활용



### CAM by Zhou et al.

* FC layers를 포함하지 않는 CNN 분류기에만 사용 가능
* Interpretability를 위해 accuracy를 일부 희생



### But, Grad-CAM

* CAM의 generalization
* VGG와 같은 FC layers가 포함된 모델에서도 사용 가능
* Captioning, segmentation 등 분류 외의 작업에서도 활용 가능
* Class-discriminative (이미지에서 Class간의 localize 되는 부분이 잘 구분됨)
* Guided Grad-CAM: Class-discriminative & High-resolution (localize 되는 부분을 정교한 해상도로 추출)

![](./img/GradCAM_4.png)



## Grad-CAM

![GradCAM_1](.\img\GradCAM_1.png)



* Convolutional layers는 FC layers에서 lost되는 spatial information을 가지고 있음
* 아이디어: 마지막 convolutional layers에 전달되는 gradient를 활용하자  (어떤 feature map이 classification에 큰 비중을 차지하는지)

1. Compute the gradient of the score for class $c$ with respect to feature map activations: $A^k$: $\frac{\partial y^c}{\partial A^k _{ij}}$
2. GAP over the width and height dimensions, to obtain the neuron importance weights: $\alpha ^c _k = \frac{1}{Z} \sum_i \sum_j \frac{\partial y^c}{\partial A^k _{ij}}$
3. Take ReLU to the linear combination: $L^c _{Grad-CAM} = ReLU(\sum_k \alpha ^c _k A^k)$
   Why ReLU? 해당 class에 positive influence를 주는 feature만을 고려함

* Grad-CAM은 CAM의 generalization (증명 생략)



* Counterfactual explanation: network가 prediction을 바꿀 때 고려하는 region
* 추출 방법: gradient의 부호를 바꾼다 (class에 negative influence를 주는 region들을 고려하게 됨)



## Evaluating Localization Ability of Grad-CAM

* VGG-16, AlexNet, GoogleNet classifier를 이용해 Grad-CAM의 localization 성능 측정
* CAM은 FC layer를 제거해야 하므로 기존 모델의 classification 성능을 약화시킴
* Grad-CAM은 classification accuracy를 낮추지 않은 채 높은 localization accuracy 달성

![GradCAM_2](.\img\GradCAM_2.png)



## Evaluating Visualizations

* AMT 직원 43명에게 설문 조사를 진행
* 질문 1: class-discrimanativeness를 판단
* 질문 2: 어떤 model이 더 신뢰도 높은 근거를 제공하는지 여부를 판단

![GradCAM_3](.\img\GradCAM_3.png)

* 설문 결과, Grad-CAM이 가장 높은 interpretability와 faithfulness를 가지고 있음



## Diagnosing image classification CNNs with Grad-CAM

* Grad-CAM을 통해 VGG-16이 분류에 실패한 이미지들의 decision region을 살펴봤을 때, 왜 그러한 결과가 나왔는지 justify 가능함
* Grad-CAM은 adversarial noise에 대해서 robust (noise를 합성한 이미지에서도 같은 localization을 유지함)
* Grad-CAM을 통해 dataset의 bias를 진단할 수 있음 (의사와 간호사를 classify하는 model이 청진기, 간호사 가운을 근거로 classify하는 게 아니라 사람의 얼굴, 즉 성별에 근거해 classify하도록 학습됨 -> 남자 간호사, 여자 의사 image를 dataset에 추가)

![](./img/GradCAM_5.png)



#### + Image Captioning,  VQA에서도 적절한 localization을 제공



## Conclusion

* AI system은 intelligent할 뿐만 아니라, 판단과 행동의 근거를 제시하여야 인간이 신뢰할 수 있음
* Image뿐만 아니라 강화 학습, 자연어 처리, 영상 처리 분야 등에서도 설명 가능한 모델이 필요함 (Further research)