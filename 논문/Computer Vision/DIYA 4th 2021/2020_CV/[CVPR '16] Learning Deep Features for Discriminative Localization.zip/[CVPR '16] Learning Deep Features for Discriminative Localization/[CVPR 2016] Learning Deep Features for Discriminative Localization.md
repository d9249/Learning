## Motivation

이미지 분류 문제를 풀면서 딥러닝 모델이 과연 어떤 정보에 기반하여 이러한 분류 결과를 냈을까라는 궁금증을 가질 수 있다. 아래의 그림은 "Visualizing and Understanding Convolution Networks"라는 논문에서 가져온 것으로, 완전히 학습된 모델에서 각 layer의 feature map을 시각화 한 것이다. 이와 같은 이전 연구들에서는 CNN 모델의 얕은 층에서는 대상의 edge와 같은 간단한 정보를 찾아내고 깊은 layer에서는 보다 고차원적인 feature를 추출한다는 것을 밝혀냈지만, 모델이 어떤 정보를 통해서 최종적인 분류 결과를 냈는지는 알 수가 없다. Classification 문제를 풀기 위해 모델을 학습하는 동시에 input 이미지의 중요한 부분(discirminative region)을 캡쳐해낼 수 있는 방법이 바로 이 논문에서 제시하는 Class Activation Map(CAM)이다.

![](resources/14441C350A924DE32C48E2D586609AD6.jpg)

## 1. Introduction

### Linear classifier가 달린 CNN 모델들은 localization 정보를 상실한다.
- VGG, ResNet과 같은 기존 CNN 모델들은 마지막에 분류를 위하여 FC layer가 달려있다.

![](resources/B02562F1079771565EAC791AEA0EE2B1.jpg)

- 위의 그림(ResNet50)에서도 convolution layer에서는 $2048 \times 512 \times 1 \times 1$의 weight를 가지지만 FC layer(avg pooling + flatten + addmm) 를 거치면서 flatten opearation이 불리게 되고, 이 과정에서 feature 정보가 일그러지게 된다. 이 지점이 convolution layer의 localization ability가 상실되는 부분이다.
- "Network In Network" 논문과 GoogLeNet 논문에서는 파라미터 수 감소를 위해 FC layer를 제거하고 average pooling을 사용함.
    + CIFAR-10의 경우, 10개의 class를 분류해야하므로 마지막 conv layer의 feature map channel 수를 10으로 맞추고, 각 채널마다 weighted sum을 하여 이를 logits과 같이 사용함.
        + eX) 첫 번째 채널은 첫번째 class에 대한 logit.
        + 가장 weighted sum 값이 큰 채널이 예측 클래스가 됨
- 위와 같은 방법을 사용하면 마지막에 flatten 연산을 사용하지 않았기 때문에 feature map의 localization 정보가 소실되지 않음.

> NIN 논문에서는 global average pooling을 오버피팅 방지를 위한 정규화 용도로 사용했지만, 이 논문에서는 localization ability에 주목했다는 차이가 있음.

![](resources/0CDADA65BFA430576F2177CDD107F338.jpg)

### 이전 Related Works들과의 차이점
- E2E 학습이 가능하며, single forward pass 만으로 localizing이 가능하다.
- Global Max Pooling(GMP)는 object의 경계선 부분에 대해서만 localizing을 하는 반면에 Global Average Pooling(GAP)는 대상의 중요한 부분 전체를 포착할 수 있다.
- 이전 연구에서 이미 CNN이 학습 과정에서 object detection을 위한 정보를 학습한다는 것을 밝혔지만 이들은 FC layer는 무시하고 conv layer 개별에 대해서 분석을 함. 반면, 이 연구는 분류 문제를 풀 수 있는 완전한 CNN 모델 구조에서 E2E 학습을 하더라도 이미지의 중요한 부분을 특정 가능함을 보임.

## 2. Class Activation Mapping (CAM)

이 섹션에서는 CNN 모델에서 GAP를 활용하여 어떻게 CAN을 생성할 수 있는지 그 방법에 대한 내용을 다룬다.

- 기본적인 GoogLeNet의 아키텍쳐를 활용하였고, 마지막 output layer(classification의 경우 probability를 뽑기 위한 softmax) 이전에 convolution feature map에 GAP를 적용하여, 이를 categorical ouput을 내뱉는 FC layer와 같이 사용함.
- 이와 같은 구조의 모델에서 이미지의 중요한 부분을 파악하기 위해선 단순히 output layer의 weights를 마지막 convolution feature map으로 projecting 하기만 하면 됨.

> 참고) GoogLeNet의 전체 구조(torchvision의 구현체)

![](resources/09058076A1C376055109938D8DB05652.jpg)

> GoogLeNet에 활용된 inception 모듈

![](resources/85EDA88B2954639CB91A90584201AB6D.jpg)

![](resources/9FEC2FB5E92FF414A8F04E972C48F4CE.jpg)

- 위의 Figure 2에서는 GAP를 통해 마지막 conv layer의 feature map의 spatial average를 추출할 수 있음을 보여준다.
- 마지막 feature map에 대해서 weighted sum을 함으로써 CAM을 얻을 수 있다.

### Specification

- $f_k(x,y)$: 마지막 conv layer의 unit(채널) $k$의 activation map의 $(x, y)$ 좌표의 값.
    + 마지막 conv layer의 $k$ 번째 채널의 값 중 $(x, y)$ 좌표에 위치한 값
- $F_k$: unit $k$의 GAP 이후의 값
    + $F_k = \sum_{x,y}{f_k(x,y)}$ (reduced sum)
- $w_k^c$: class $c$의 $F_k$가 얼마나 중요한가.
    + 채널 $k$와 클래스 $c$에 대응되는 값
    + $w_k^c$가 클수록 $F_k$가 중요
- $S_c$: class score(softmax의 input)
    + $\sum_kw_k^cF_k$
- $P_c$: softamx 이후의 값
- $M_c$: 클래스 $c$에 대한 CAM
    + $(x,y)$에 위치한 값이 클래스 $c$로 분류되는데 미치는 중요도

![](resources/6BE3EDACF3B62D542522269230897F79.jpg)

최종적으로 $S_c = \sum_{x,y}M_c(x,y)$를 얻을 수 있음. 
- Figure 2에서 GAP 이전의 feature map이 $f_k$이고, 이들을 채널 단위로 찹쳐주면 $F_k$가 됨.
    + 그림에서 동그라미 하나가 $F_k$에 해당.
- 이들을 softmax에 넣어서 분류 결과를 뽑기 위해서 FC layer 하나가 들어가는데 이 때 weight들이 $w_k^c$

## CAM Examples

![](resources/EF1889871BB284674B04F16455C117FD.jpg)







