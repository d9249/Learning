#include	"unp.h"
#include	<time.h>
#include <sys/socket.h>

struct client_info {
	char clientAddr[32];
	int clientPort;
};

int main(int argc, char **argv)
{
	int listenfd, connfd;
	struct sockaddr_in	servaddr;
	struct sockaddr_in	clntaddr;
	struct client_info cliinfo[5];
	char buff[MAXLINE];
	time_t	ticks;
	int num = atoi(argv[1]);
	char temp[20];
	socklen_t clntaddr_size;
	int conNum = 0;

	listenfd = Socket(AF_INET, SOCK_STREAM, 0);

	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family      = AF_INET;
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	servaddr.sin_port        = htons(num);	/* daytime server */

	Bind(listenfd, (SA *) &servaddr, sizeof(servaddr));

	Listen(listenfd, LISTENQ);
	
	while(1) {
	
		clntaddr_size = sizeof(clntaddr);
			connfd = Accept(listenfd, (struct sockaddr*)&clntaddr, &clntaddr_size);
		
		strcpy(cliinfo[conNum].clientAddr, inet_ntoa(clntaddr.sin_addr));
		cliinfo[conNum].clientPort = ntohs(clntaddr.sin_port);
		printf("connection from %s, Port %d\n", cliinfo[conNum].clientAddr, cliinfo[conNum].clientPort);
        
        	ticks = time(NULL);
        	snprintf(buff, sizeof(buff), "%.24s\r\n", ctime(&ticks));
        	Write(connfd, buff, strlen(buff));
			Close(connfd);
	}
	
}
