#include	"unp.h"
#include	<time.h>
#include <sys/socket.h>

int
main(int argc, char **argv)
{
	int					listenfd, connfd;
	struct sockaddr_in	servaddr;
	struct sockaddr_in	clntaddr;
	char				buff[MAXLINE];
	time_t				ticks;
	int num = atoi(argv[1]);
	char temp[20];
	socklen_t clntaddr_size;

	listenfd = Socket(AF_INET, SOCK_STREAM, 0);

	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family      = AF_INET;
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	servaddr.sin_port        = htons(num);	/* daytime server */

	Bind(listenfd, (SA *) &servaddr, sizeof(servaddr));

	Listen(listenfd, LISTENQ);
	clntaddr_size = sizeof(clntaddr);
	for ( ; ; ) {
		connfd = Accept(listenfd, (struct sockaddr*)&clntaddr, &clntaddr_size);

	inet_ntop(AF_INET, &clntaddr.sin_addr.s_addr, temp, sizeof(temp));
        printf("connection from %s, port %d\n",temp, atoi(argv[1]));
        
        ticks = time(NULL);
        snprintf(buff, sizeof(buff), "%.24s\r\n", ctime(&ticks));
        Write(connfd, buff, strlen(buff));
		Close(connfd);
	}
	
	while(1){
    		
        	
    	}
}
