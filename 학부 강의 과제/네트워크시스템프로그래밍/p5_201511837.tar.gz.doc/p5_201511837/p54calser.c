#include "unp.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct args {
	long arg1;
	long arg2;
};

struct result {
	char sum;
};

void str_echo(int sockfd);
int bin_add(int binary1, int binary2);
char* addBinary(char* a, char* b);
int bin_verify(char str[]);
void main(int argc, char **argv) {
	int listenfd, connfd;
	pid_t childpid;
	socklen_t clilen;
	struct sockaddr_in cliaddr, servaddr;
	void sig_chld(int);
	listenfd = Socket (AF_INET, SOCK_STREAM, 0);
	bzero (&servaddr, sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	servaddr.sin_port = htons(SERV_PORT);
	Bind(listenfd, (SA *) &servaddr, sizeof(servaddr));
	Listen(listenfd, LISTENQ);
	Signal (SIGCHLD, str_echo);
	for ( ; ; ) {
		clilen = sizeof(cliaddr);
		if ( (connfd = accept (listenfd, (SA *) &cliaddr, &clilen)) < 0) {
			if (errno == EINTR)
				continue;
			else
				err_sys("accept error");
		}
		if ( (childpid = Fork()) == 0) {
			Close(listenfd);
			str_echo(connfd);
			exit(0);
		}
		Close (connfd);
	}
}

void str_echo(int sockfd) {
	ssize_t n;
	struct args args;
	struct result result;
	char num1[33], num2[33], res[33];
	for ( ; ; ) {
		if ( (n = Readn(sockfd, &args, sizeof(args))) == 0)
			return;
		sprintf(num1, "%ld", args.arg1);
		sprintf(num2, "%ld", args.arg2);
		addBinary(num1, num2);
		
		sprintf(res, "%s\n", addBinary(num1, num2));
		printf("%s", res);
		result.sum = res;
		Writen(sockfd, &result, sizeof (result));
	}
}

int bin_add(int binary1, int binary2) {
	int i = 0, remainder = 0, sum[20], res[80];
	char buf;
	while (binary1 != 0 || binary2 != 0) {
        	sum[i++] =(binary1 % 10 + binary2 % 10 + remainder) % 2;
        	remainder =(binary1 % 10 + binary2 % 10 + remainder) / 2;
        	binary1 = binary1 / 10;
        	binary2 = binary2 / 10;
    	}
    	if (remainder != 0)
        	sum[i++] = remainder;
    	--i;
    	while (i >= 0)
        	res[i] = printf("%d", sum[i--]);
        printf("\n%d\n", *res);
    	return 0;
}

char* addBinary(char* a, char* b) {
    int n, m;
    for (n=0; *a; a++, n++) ;
    for (m=0; *b; b++, m++) ;
    char *p = (char*)malloc(m>n ? m+2 : n+2), *last = p;
    int c = 0;
    while (n || m || c) {
        int s = c;
        if (n) {
            s += *(--a)-'0';
            --n;
        }
        if (m) {
            s += *(--b)-'0';
            --m;
        }
        *last++ = (s&1)+'0';
        c = s>>1;
    }
    *last=0;
    char *start = p, t;
    while (start+1 < last) { // reverse string
        t = *start;
        *start++=*(--last);
        *last=t;
    }
    return p;
}
